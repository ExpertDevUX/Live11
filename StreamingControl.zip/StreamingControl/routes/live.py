from flask import Blueprint, render_template, flash, redirect, url_for, request, jsonify, abort
from flask_login import login_required, current_user
import os
import secrets
from werkzeug.utils import secure_filename
import datetime
from sqlalchemy import desc

from app import db
from models import LiveStream, Category, ChatMessage, StreamAnalytics, User, SupportChat
from utils import allowed_file, save_uploaded_file

live_bp = Blueprint('live', __name__, url_prefix='/live')


@live_bp.route('/')
def index():
    """Show all live streams currently active."""
    # Get active live streams
    live_streams = LiveStream.query.filter_by(is_live=True, is_public=True).order_by(desc(LiveStream.viewer_count)).all()
    
    # Get featured stream (the one with most viewers or most recent)
    featured_stream = None
    if live_streams:
        featured_stream = live_streams[0]
        live_streams = live_streams[1:]  # Remove featured from regular list
    
    # Get categories
    categories = Category.query.all()
    
    # Get some recommended on-demand media
    from models import Media
    recommended_media = Media.query.filter_by(is_public=True, is_processed=True).order_by(desc(Media.created_at)).limit(8).all()
    
    return render_template('live/index.html', 
                          live_streams=live_streams,
                          featured_stream=featured_stream,
                          categories=categories,
                          recommended_media=recommended_media,
                          now=datetime.datetime.utcnow())


@live_bp.route('/<int:stream_id>')
def view_stream(stream_id):
    """View a specific live stream."""
    stream = LiveStream.query.get_or_404(stream_id)
    
    # Check if private and not owner
    if not stream.is_public and (not current_user.is_authenticated or current_user.id != stream.user_id):
        flash('This stream is private.', 'warning')
        return redirect(url_for('live.index'))
    
    # Increment viewer count if live
    if stream.is_live:
        stream.viewer_count += 1
        db.session.commit()
    
    # Get related streams
    related_streams = []
    if stream.category:
        related_streams = LiveStream.query.filter(
            LiveStream.category_id == stream.category_id,
            LiveStream.id != stream.id,
            LiveStream.is_live == True,
            LiveStream.is_public == True
        ).limit(4).all()
    
    # If not enough related streams by category, add some general live streams
    if len(related_streams) < 4:
        additional_streams = LiveStream.query.filter(
            LiveStream.id != stream.id,
            LiveStream.is_live == True,
            LiveStream.is_public == True
        ).limit(4 - len(related_streams)).all()
        related_streams.extend(additional_streams)
    
    # Get recent media from this streamer
    from models import Media
    recent_media = Media.query.filter_by(
        user_id=stream.user_id,
        is_public=True,
        is_processed=True
    ).order_by(desc(Media.created_at)).limit(4).all()
    
    # Get active support chat for this stream if user is authenticated
    active_support_chat = None
    if current_user.is_authenticated:
        # Look for an active support chat for this user and stream
        active_support_chat = SupportChat.query.filter_by(
            user_id=current_user.id,
            live_stream_id=stream_id,
            is_active=True
        ).first()
    
    return render_template('live/view.html', 
                          stream=stream,
                          related_streams=related_streams,
                          recent_media=recent_media,
                          active_support_chat=active_support_chat,
                          now=datetime.datetime.utcnow())


@live_bp.route('/setup', methods=['GET', 'POST'])
@login_required
def setup_stream():
    """Set up a new live stream."""
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description', '')
        category_id = request.form.get('category_id')
        is_public = 'is_public' in request.form
        
        if not title:
            flash('Title is required.', 'danger')
            return redirect(url_for('live.setup_stream'))
        
        # Generate a secure random stream key
        stream_key = secrets.token_hex(16)
        
        # Create a new stream
        new_stream = LiveStream(
            title=title,
            description=description,
            user_id=current_user.id,
            stream_key=stream_key,
            is_public=is_public,
            created_at=datetime.datetime.utcnow(),
            stream_settings={
                'resolution': '720p',
                'bitrate': '2500k',
                'fps': 30,
                'video_codec': 'h264',
                'audio_codec': 'aac'
            }
        )
        
        if category_id:
            new_stream.category_id = category_id
        
        # Handle thumbnail upload
        if 'thumbnail' in request.files:
            thumbnail_file = request.files['thumbnail']
            if thumbnail_file and thumbnail_file.filename and allowed_file(thumbnail_file.filename):
                file_path = save_uploaded_file(thumbnail_file, subfolder='thumbnails')
                if file_path:
                    new_stream.thumbnail_path = file_path
        
        db.session.add(new_stream)
        db.session.commit()
        
        flash('Your stream has been created successfully.', 'success')
        return redirect(url_for('live.stream_control', stream_id=new_stream.id))
    
    # For GET request
    categories = Category.query.all()
    return render_template('live/setup.html', categories=categories)


@live_bp.route('/dashboard')
@login_required
def dashboard():
    """User's streaming dashboard showing their streams."""
    # Get all streams for the current user
    streams = LiveStream.query.filter_by(user_id=current_user.id).order_by(desc(LiveStream.created_at)).all()
    
    return render_template('live/dashboard.html', 
                          streams=streams,
                          now=datetime.datetime.utcnow())


@live_bp.route('/control/<int:stream_id>')
@login_required
def stream_control(stream_id):
    """Control panel for a specific stream."""
    stream = LiveStream.query.get_or_404(stream_id)
    
    # Ensure the current user owns this stream
    if stream.user_id != current_user.id:
        flash('You do not have permission to access this stream.', 'danger')
        return redirect(url_for('live.dashboard'))
    
    return render_template('live/control.html', stream=stream)


@live_bp.route('/api/start/<stream_key>', methods=['POST'])
def start_stream(stream_key):
    """API endpoint to start a stream (called by streaming software)."""
    stream = LiveStream.query.filter_by(stream_key=stream_key).first()
    
    if not stream:
        return jsonify({'success': False, 'message': 'Invalid stream key'}), 404
    
    # Update stream status
    stream.is_live = True
    stream.started_at = datetime.datetime.utcnow()
    stream.viewer_count = 0
    db.session.commit()
    
    # Create a system message in chat
    system_message = ChatMessage(
        message="Stream has started",
        is_system_message=True,
        user_id=stream.user_id,
        live_stream_id=stream.id
    )
    db.session.add(system_message)
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'Stream started successfully'})


@live_bp.route('/api/end/<stream_key>', methods=['POST'])
def end_stream(stream_key):
    """API endpoint to end a stream (called by streaming software)."""
    stream = LiveStream.query.filter_by(stream_key=stream_key).first()
    
    if not stream:
        return jsonify({'success': False, 'message': 'Invalid stream key'}), 404
    
    # Update stream status
    stream.is_live = False
    stream.ended_at = datetime.datetime.utcnow()
    
    # Store analytics
    if stream.started_at:
        duration = (stream.ended_at - stream.started_at).total_seconds()
        
        analytics = StreamAnalytics(
            date=stream.ended_at.date(),
            total_viewers=stream.viewer_count,
            peak_viewers=stream.viewer_count,  # Ideally this would be tracked throughout the stream
            average_watch_time=int(duration / max(1, stream.viewer_count)),
            unique_viewers=stream.viewer_count,  # Ideally this would track unique IPs/users
            live_stream_id=stream.id
        )
        db.session.add(analytics)
    
    # Create a system message in chat
    system_message = ChatMessage(
        message="Stream has ended",
        is_system_message=True,
        user_id=stream.user_id,
        live_stream_id=stream.id
    )
    db.session.add(system_message)
    
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'Stream ended successfully'})


@live_bp.route('/api/chat/<int:stream_id>', methods=['POST'])
@login_required
def post_chat(stream_id):
    """API endpoint to post a chat message."""
    stream = LiveStream.query.get_or_404(stream_id)
    
    # Check if stream is live
    if not stream.is_live:
        return jsonify({'success': False, 'message': 'Stream is not active'}), 400
    
    data = request.get_json()
    message = data.get('message', '').strip()
    
    if not message:
        return jsonify({'success': False, 'message': 'Message cannot be empty'}), 400
    
    # Create a new chat message
    new_message = ChatMessage(
        message=message,
        user_id=current_user.id,
        live_stream_id=stream_id,
        created_at=datetime.datetime.utcnow()
    )
    db.session.add(new_message)
    db.session.commit()
    
    # Return the message in a format suitable for display
    return jsonify({
        'id': new_message.id,
        'message': new_message.message,
        'username': current_user.username,
        'timestamp': new_message.created_at.strftime('%H:%M'),
        'is_system': False
    })


@live_bp.route('/api/chat/<int:stream_id>', methods=['GET'])
def get_chat(stream_id):
    """API endpoint to get recent chat messages."""
    stream = LiveStream.query.get_or_404(stream_id)
    
    # Get last_id from query param to enable polling for new messages
    last_id = request.args.get('last_id', 0, type=int)
    
    # Get messages newer than last_id
    messages = ChatMessage.query.filter(
        ChatMessage.live_stream_id == stream_id,
        ChatMessage.id > last_id
    ).order_by(ChatMessage.created_at).limit(50).all()
    
    # Format messages for JSON response
    formatted_messages = []
    for msg in messages:
        username = User.query.get(msg.user_id).username if not msg.is_system_message else "System"
        formatted_messages.append({
            'id': msg.id,
            'message': msg.message,
            'username': username,
            'timestamp': msg.created_at.strftime('%H:%M'),
            'is_system': msg.is_system_message
        })
    
    return jsonify({'messages': formatted_messages})


@live_bp.route('/api/viewers/<int:stream_id>')
def get_viewers(stream_id):
    """API endpoint to get current viewer count."""
    stream = LiveStream.query.get_or_404(stream_id)
    return jsonify({'viewer_count': stream.viewer_count})


@live_bp.route('/edit/<int:stream_id>', methods=['GET', 'POST'])
@login_required
def edit_stream(stream_id):
    """Edit stream settings."""
    stream = LiveStream.query.get_or_404(stream_id)
    
    # Ensure the current user owns this stream
    if stream.user_id != current_user.id:
        flash('You do not have permission to edit this stream.', 'danger')
        return redirect(url_for('live.dashboard'))
    
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description', '')
        category_id = request.form.get('category_id')
        is_public = 'is_public' in request.form
        
        if not title:
            flash('Title is required.', 'danger')
            return redirect(url_for('live.edit_stream', stream_id=stream_id))
        
        # Update stream details
        stream.title = title
        stream.description = description
        stream.is_public = is_public
        
        if category_id:
            stream.category_id = category_id
        else:
            stream.category_id = None
        
        # Handle thumbnail upload
        if 'thumbnail' in request.files:
            thumbnail_file = request.files['thumbnail']
            if thumbnail_file and thumbnail_file.filename and allowed_file(thumbnail_file.filename):
                file_path = save_uploaded_file(thumbnail_file, subfolder='thumbnails')
                if file_path:
                    # Remove old thumbnail if it exists
                    if stream.thumbnail_path:
                        try:
                            os.remove(stream.thumbnail_path)
                        except:
                            pass  # Ignore error if file doesn't exist
                    stream.thumbnail_path = file_path
        
        # Update stream settings
        resolution = request.form.get('resolution', '720p')
        bitrate = request.form.get('bitrate', '2500k')
        fps = request.form.get('fps', 30, type=int)
        
        stream.stream_settings = {
            'resolution': resolution,
            'bitrate': bitrate,
            'fps': fps,
            'video_codec': 'h264',
            'audio_codec': 'aac'
        }
        
        db.session.commit()
        flash('Stream settings updated successfully.', 'success')
        return redirect(url_for('live.stream_control', stream_id=stream_id))
    
    # For GET request
    categories = Category.query.all()
    return render_template('live/edit.html', stream=stream, categories=categories)


@live_bp.route('/delete/<int:stream_id>', methods=['POST'])
@login_required
def delete_stream(stream_id):
    """Delete a stream."""
    stream = LiveStream.query.get_or_404(stream_id)
    
    # Ensure the current user owns this stream
    if stream.user_id != current_user.id and not current_user.is_admin:
        flash('You do not have permission to delete this stream.', 'danger')
        return redirect(url_for('live.dashboard'))
    
    # Delete associated chat messages
    ChatMessage.query.filter_by(live_stream_id=stream_id).delete()
    
    # Delete associated analytics
    StreamAnalytics.query.filter_by(live_stream_id=stream_id).delete()
    
    # Delete the stream
    db.session.delete(stream)
    db.session.commit()
    
    flash('Stream deleted successfully.', 'success')
    return redirect(url_for('live.dashboard'))


@live_bp.route('/analytics/<int:stream_id>')
@login_required
def stream_analytics(stream_id):
    """View analytics for a specific stream."""
    stream = LiveStream.query.get_or_404(stream_id)
    
    # Ensure the current user owns this stream
    if stream.user_id != current_user.id and not current_user.is_admin:
        flash('You do not have permission to view analytics for this stream.', 'danger')
        return redirect(url_for('live.dashboard'))
    
    # Get analytics for this stream
    analytics = StreamAnalytics.query.filter_by(live_stream_id=stream_id).all()
    
    return render_template('live/analytics.html', stream=stream, analytics=analytics)


@live_bp.route('/<int:stream_id>/embed')
def embed_stream(stream_id):
    """Embeddable view for a specific live stream."""
    stream = LiveStream.query.get_or_404(stream_id)
    
    # Check if stream is private
    if not stream.is_public:
        return render_template('live/embed_error.html', message="This stream is private or not available")
    
    # Increment viewer count if live
    if stream.is_live:
        stream.viewer_count += 1
        db.session.commit()
    
    # Get streamer info
    streamer = User.query.get(stream.user_id)
    
    # Get customization options from query parameters
    show_info = request.args.get('show_info', '1') == '1'
    show_watermark = request.args.get('show_watermark', '1') == '1'
    show_viewers = request.args.get('show_viewers', '1') == '1'
    theme = request.args.get('theme', 'dark')
    
    return render_template('live/embed.html', 
                          stream=stream,
                          streamer=streamer,
                          now=datetime.datetime.utcnow(),
                          show_info=show_info,
                          show_watermark=show_watermark,
                          show_viewers=show_viewers,
                          theme=theme)